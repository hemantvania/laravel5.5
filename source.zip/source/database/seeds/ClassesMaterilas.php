<?php

use Illuminate\Database\Seeder;

class ClassesMaterilas extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
