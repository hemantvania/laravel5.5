<?php
return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'label_title'           => 'Sinulla on useita kouluja.!',
    'label_subtext'         => 'Valitse jokin oletuskouluksi!',
    'label_btn'             => 'SIIRRY',
    'label_switchschool'    => 'Vaihda koulua',

];