<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'content_search_title'  => 'Etsi sisältöä',
    'school_search_title'   => 'Etsi kouluja',
    'user_search_title'     => 'Etsi käyttäjää',
    'btn_delete_selected'   => 'Poista',
];