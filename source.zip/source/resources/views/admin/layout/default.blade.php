@include("admin.layout.defaultheader")

@include("admin.layout.defaultsidebar")

@yield("content")



@include("admin.layout.defaultfooter")
