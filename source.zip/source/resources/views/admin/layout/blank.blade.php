@include("admin.layout.blankheader")


@yield("content")



@include("admin.layout.blankfooter")
