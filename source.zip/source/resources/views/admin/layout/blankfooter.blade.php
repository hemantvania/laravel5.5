
<!-- jQuery 3 -->
<script src="{{ asset('assests/admin/bower_components/jquery/dist/jquery.min.js') }}"></script>

<!-- Bootstrap 3.3.7 -->
<script src="{{ asset('assests/admin/bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>

<script src="{{ asset('assests/admin/plugins/iCheck/icheck.min.js') }}"></script>

@yield("page-js")


</body>
</html>