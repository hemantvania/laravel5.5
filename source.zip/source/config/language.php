<?php

return [

	'available_locales' => ['fi','sv','en'],
	'option' => [
        'fi' => 'Suomi',
        'sv' => 'Svenska',
	    'en' => 'English'
	]
];
